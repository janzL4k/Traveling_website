
package tugas.nestedif;
import java.util.Scanner;

public class TugasNestedIf {

   
    public static void main(String[] args) {
        //NAMA EKA BAYU SUPUTRA
        // TUGAS ALPRO NESTEDIF
        // KELAS C SESI 2
        System.out.println("====== SELAMAT DATANG DI PELABUHAN LOMBOK ======");
      Scanner input = new Scanner (System.in);
      String kapal;
      int tiket;
        System.out.print("Masukan Nama kapal anda =");
        kapal = input.nextLine();
        System.out.print("Masukan Tiket aanda =");
       tiket = input.nextInt();
        
        switch (kapal){
            case "Surya" :
                if (tiket==1){
                    System.out.println("kapal akan berangkat pukul 08:00 WITA tujuan Bali");
                }else if (tiket==2){
                    System.out.println("kapal akan berangkat pukul 12:00 WITA tujuan Bali");
                }else if (tiket==3){
                    System.out.println("kapal akan berangkat pukul 16:00 WITA tujuan Bali");
                }else {
                    System.out.println("maaf tiket  anda  salah");
                }
                break;
            case "Abadi" :
                if (tiket==1){
                    System.out.println("kapal akan berangkat pukul 09:00 WITA tujuan Sumbawa");
                }else if (tiket==2){
                    System.out.println("kapal akan berangkat pukul 13:30 WITA tujuan Sumbawa");
                }else if (tiket==3){
                    System.out.println("kapal akan berangkat pukul 18:00 WITA tujuan Sumbawa");
                }else {
                    System.out.println("maaf tiket  anda  salah");
                }
                break;
            case "Cahaya" :
                if (tiket==1){
                    System.out.println("kapal akan berangkat pukul 10:00 WITA tujuan Bima");
                }else if (tiket==2){
                    System.out.println("kapal akan berangkat pukul 14:00 WITA tujuan Bima");
                }else if (tiket==3){
                    System.out.println("kapal akan berangkat pukul 20:00 WITA tujuan Bima");
                }else {
                    System.out.println("maaf tiket  anda  salah");
                }
                break;
                
        }
    }
    
}
